# EyeMood — Vercel

Files:
- index.html
- api/analyze.js
- package.json

Deploy from GitHub to Vercel. Add `GEMINI_API_KEY` in Vercel Environment Variables.

Do not commit your Gemini API key to GitHub.
