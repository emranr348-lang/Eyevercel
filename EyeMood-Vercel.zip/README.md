# EyeMood

A simple Vercel-ready web app that uses the phone camera and Gemini to describe visible facial expression cues.

## Deploy

1. Upload this project to GitHub.
2. Import the GitHub repository into Vercel.
3. In Vercel, open Settings -> Environment Variables.
4. Add:
   - Name: `GEMINI_API_KEY`
   - Value: your Gemini API key
5. Redeploy.
6. Open the Vercel URL on your Android phone.
7. Allow camera permission.

## Important

This app is not a medical or psychological diagnostic tool. Facial expressions cannot reliably reveal a person's true internal state, and the 24-hour outlook is entertainment rather than a factual prediction.
