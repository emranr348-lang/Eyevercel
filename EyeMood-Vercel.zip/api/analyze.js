export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const { imageData } = req.body || {};
    if (!imageData) return res.status(400).json({ error: "No image provided." });

    const key = process.env.GEMINI_API_KEY;
    if (!key) return res.status(500).json({ error: "GEMINI_API_KEY is not configured in Vercel." });

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(key),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{
            parts: [
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: imageData.replace(/^data:image\/\w+;base64,/, "")
                }
              },
              {
                text:
`Analyze this face image for visible facial expression only. Do not diagnose health or mental conditions and do not claim to know a person's hidden feelings with certainty. Do not infer age, gender, ethnicity, identity, or sensitive traits.

Return ONLY valid JSON with:
{
  "mood": "one short label",
  "confidence": 0-100,
  "visible_cues": ["short cue", "short cue"],
  "response": "one friendly short response",
  "outlook24h": "an entertainment-style general outlook for the next 24 hours, clearly not a prediction"
}

Use cautious wording because a face image cannot reliably predict future events or a person's true internal state.`
              }
            ]
          }],
          generationConfig: {
            temperature: 0.7,
            responseMimeType: "application/json"
          }
        })
      }
    );

    if (!response.ok) {
      const detail = await response.text();
      return res.status(502).json({ error: "Gemini request failed.", detail });
    }

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) return res.status(502).json({ error: "Gemini returned no result." });

    let result;
    try {
      result = JSON.parse(text);
    } catch {
      result = {
        mood: "Unclear",
        confidence: 0,
        visible_cues: [],
        response: text,
        outlook24h: "This is an entertainment-style outlook, not a real prediction."
      };
    }

    return res.status(200).json(result);
  } catch (e) {
    return res.status(500).json({ error: e.message || "Unexpected error." });
  }
}